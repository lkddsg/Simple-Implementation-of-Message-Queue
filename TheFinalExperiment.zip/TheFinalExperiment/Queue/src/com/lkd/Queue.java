package com.lkd;

import java.util.concurrent.LinkedBlockingQueue;

public class Queue {
    public static LinkedBlockingQueue<Integer> myQueue=new LinkedBlockingQueue<>();
}
