package com.lkd;

public class StructureMessage {

    private String ID=null;
    private String Tag=null;
    private String data=null;

    public StructureMessage(String  ID, String tag, String data) {
        this.ID = ID;
        this.Tag = tag;
        this.data = data;
    }
}
